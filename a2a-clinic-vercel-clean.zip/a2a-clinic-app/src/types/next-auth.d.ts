import NextAuth, { DefaultSession } from 'next-auth'
import 'next-auth/jwt'

declare module 'next-auth' {
  interface Session {
    accessToken?: string
    error?: string
    user: DefaultSession['user'] & {
      id?: string
      interests?: string[]
      expertise?: string[]
    }
  }

  interface User {
    id?: string
    interests?: string[]
    expertise?: string[]
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    accessToken?: string
    refreshToken?: string
    accessTokenExpires?: number
    error?: string
    user?: {
      id?: string
      name?: string | null
      email?: string | null
      image?: string | null
      interests?: string[]
      expertise?: string[]
    }
  }
}
