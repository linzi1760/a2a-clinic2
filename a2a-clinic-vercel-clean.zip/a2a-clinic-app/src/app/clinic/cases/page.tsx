'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'

type MyCase = {
  id: string
  title: string
  status: string
  isPublic: boolean
  consultations: { id: string }[]
  suggestedConnections: { id: string }[]
  updatedAt: string
}

export default function MyCasesPage() {
  const { status } = useSession()
  const [cases, setCases] = useState<MyCase[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status !== 'authenticated') {
      setLoading(false)
      return
    }

    fetch('/api/cases')
      .then((res) => res.json())
      .then((data) => setCases(data.data?.cases || []))
      .finally(() => setLoading(false))
  }, [status])

  if (status === 'unauthenticated') {
    return (
      <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)] px-4 py-16">
        <div className="mx-auto max-w-3xl rounded-3xl bg-white p-10 text-center shadow-xl">
          请先登录，再查看你的病例。
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)]">
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black text-gray-900">我的病例</h1>
            <p className="mt-2 text-gray-600">这里可以回看你发起过的病例，以及公开会诊带来的连接效果。</p>
          </div>
          <Link href="/clinic/lobby" className="rounded-full bg-blue-600 px-5 py-3 font-semibold text-white hover:bg-blue-700">
            新建病例
          </Link>
        </div>

        <div className="mt-8 space-y-4">
          {loading ? (
            <div className="rounded-3xl bg-white p-6 shadow-xl">加载中...</div>
          ) : cases.length === 0 ? (
            <div className="rounded-3xl bg-white p-6 shadow-xl">你还没有创建病例，先去发起一个吧。</div>
          ) : (
            cases.map((item) => (
              <Link key={item.id} href={`/clinic/diagnosis/${item.id}`} className="block rounded-3xl bg-white p-6 shadow-xl hover:shadow-2xl">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-xl font-bold text-gray-900">{item.title}</h2>
                  <div className="flex flex-wrap gap-2 text-sm">
                    <span className="rounded-full bg-gray-100 px-3 py-1 text-gray-700">状态：{item.status}</span>
                    <span className="rounded-full bg-blue-50 px-3 py-1 text-blue-700">{item.isPublic ? '公开会诊中' : '私有病例'}</span>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-500">
                  <span>会诊回复：{item.consultations.length}</span>
                  <span>推荐连接：{item.suggestedConnections.length}</span>
                  <span>更新时间：{new Date(item.updatedAt).toLocaleString()}</span>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
