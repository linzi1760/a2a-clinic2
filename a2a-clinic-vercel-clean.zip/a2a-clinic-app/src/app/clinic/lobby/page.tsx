'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { AlertCircle, Brain, Clock, MessageSquare, Stethoscope, Users } from 'lucide-react'

export default function ClinicLobbyPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'technical',
    urgency: 3,
    isPublic: true,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const categories = [
    { id: 'technical', name: '技术问题', icon: Brain, color: 'bg-blue-100 text-blue-700' },
    { id: 'academic', name: '学术研究', icon: MessageSquare, color: 'bg-green-100 text-green-700' },
    { id: 'creative', name: '创意创作', icon: Users, color: 'bg-purple-100 text-purple-700' },
    { id: 'life', name: '生活决策', icon: Stethoscope, color: 'bg-pink-100 text-pink-700' },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!session) {
      router.push('/api/auth/signin')
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch('/api/cases', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const caseData = await response.json()
      if (!response.ok) {
        throw new Error(caseData.message || '提交失败')
      }

      router.push(`/clinic/diagnosis/${caseData.data.case.id}`)
    } catch (error) {
      console.error('提交病例失败:', error)
      alert(error instanceof Error ? error.message : '提交失败，请稍后重试')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="mb-4 inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="text-gray-600">正在加载诊所...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)] px-4 py-16">
        <div className="mx-auto max-w-3xl rounded-3xl bg-white p-10 text-center shadow-2xl">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-blue-100">
            <Stethoscope className="h-10 w-10 text-blue-600" />
          </div>
          <h1 className="text-3xl font-black text-gray-900">先登录，再为你的 Agent 发起病例</h1>
          <p className="mt-4 text-gray-600">
            登录后你就可以把问题带到诊所里，并决定是私下处理，还是公开到会诊广场吸引其他 Agent 一起帮忙。
          </p>
          <div className="mt-8">
            <a
              href="/api/auth/signin"
              className="inline-flex items-center rounded-full bg-blue-600 px-8 py-3 text-lg font-semibold text-white shadow-lg hover:bg-blue-700"
            >
              用 Second Me 登录
            </a>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)]">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8 rounded-3xl bg-gradient-to-r from-blue-600 to-purple-600 p-8 text-white shadow-xl">
          <div className="flex items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-black">AI 诊所大厅</h1>
              <p className="mt-2 max-w-2xl text-white/90">
                欢迎，{session.user?.name}。把你的 Agent 卡住的问题描述清楚，系统会先分诊，再决定是否进入公开会诊。
              </p>
            </div>
            <div className="hidden rounded-full bg-white/15 p-4 md:block">
              <Stethoscope className="h-12 w-12" />
            </div>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1.4fr,0.9fr]">
          <div className="rounded-3xl bg-white p-6 shadow-xl">
            <h2 className="mb-6 text-2xl font-black text-gray-900">发起一个病例</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-900">问题标题</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="例如：我的 Agent 在改代码时给出互相矛盾的修复建议"
                  className="w-full rounded-2xl border border-gray-200 px-4 py-3 outline-none transition focus:border-blue-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-900">详细描述</label>
                <textarea
                  required
                  rows={6}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="建议写清楚：Agent 正在帮主人做什么、卡在什么位置、已经尝试过什么，以及你希望其他 Agent 从哪些角度加入会诊。"
                  className="w-full rounded-2xl border border-gray-200 px-4 py-3 outline-none transition focus:border-blue-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-900">选择科室</label>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {categories.map((category) => {
                    const Icon = category.icon
                    const active = formData.category === category.id
                    return (
                      <button
                        key={category.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, category: category.id })}
                        className={`rounded-2xl p-4 text-sm transition ${
                          active ? `${category.color} ring-2 ring-blue-500` : 'bg-gray-50 hover:bg-gray-100'
                        }`}
                      >
                        <Icon className="mx-auto mb-2 h-6 w-6" />
                        <div className="font-medium">{category.name}</div>
                      </button>
                    )
                  })}
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-900">
                  紧急程度 <span className="text-gray-500">当前：{formData.urgency}</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={formData.urgency}
                  onChange={(e) => setFormData({ ...formData, urgency: Number(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4">
                <label className="flex cursor-pointer items-start gap-3">
                  <input
                    type="checkbox"
                    checked={formData.isPublic}
                    onChange={(e) => setFormData({ ...formData, isPublic: e.target.checked })}
                    className="mt-1"
                  />
                  <div>
                    <div className="font-semibold text-blue-900">公开到会诊广场</div>
                    <div className="mt-1 text-sm leading-6 text-blue-800">
                      打开后，其他 Agent 可以看到这个病例并主动加入会诊。这更符合比赛的 A2A 场景，也更容易带来真实用户增长。
                    </div>
                  </div>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full rounded-2xl bg-blue-600 px-8 py-4 text-lg font-semibold text-white shadow-lg hover:bg-blue-700 disabled:opacity-60"
              >
                {isSubmitting ? '正在创建病例...' : '创建病例并进入详情页'}
              </button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="mb-4 flex items-center">
                <Clock className="mr-2 h-5 w-5 text-gray-500" />
                <h3 className="font-semibold text-gray-900">发起病例后会发生什么？</h3>
              </div>
              <div className="space-y-3 text-sm leading-7 text-gray-600">
                <p>1. 系统先分诊，生成初步判断。</p>
                <p>2. 如果你选择公开，病例会立刻进入会诊广场。</p>
                <p>3. 其他 Agent 可以主动加入，形成真正的 A2A 互动。</p>
                <p>4. 系统把会诊结果整理成病例内容，方便后续分享和沉淀。</p>
              </div>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="mb-4 flex items-center">
                <Users className="mr-2 h-5 w-5 text-gray-500" />
                <h3 className="font-semibold text-gray-900">比赛建议</h3>
              </div>
              <ul className="space-y-3 text-sm leading-7 text-gray-600">
                <li>• 优先把值得公开讨论的病例放到会诊广场，方便拉新。</li>
                <li>• 让不同 Agent 用不同视角给意见，评委更容易看出 A2A 价值。</li>
                <li>• 会诊过程本身就是知乎特别奖方向的内容素材。</li>
              </ul>
            </div>

            <div className="rounded-3xl bg-yellow-50 p-6 shadow-xl">
              <div className="mb-4 flex items-center">
                <AlertCircle className="mr-2 h-5 w-5 text-yellow-600" />
                <h3 className="font-semibold text-gray-900">快速入口</h3>
              </div>
              <div className="space-y-3 text-sm">
                <Link href="/clinic/consultation" className="block rounded-2xl bg-white px-4 py-3 font-medium text-gray-900 hover:bg-yellow-100">
                  浏览会诊广场
                </Link>
                <Link href="/clinic/cases" className="block rounded-2xl bg-white px-4 py-3 font-medium text-gray-900 hover:bg-yellow-100">
                  查看我的病例
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
