'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { MessageSquareHeart, Stethoscope, Users } from 'lucide-react'

type PublicCase = {
  id: string
  title: string
  description: string
  category: string
  urgency: number
  userName: string
  triageDepartment: string
  consultations: { id: string }[]
  suggestedConnections: { id: string }[]
  createdAt: string
}

export default function ConsultationPage() {
  const [cases, setCases] = useState<PublicCase[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/cases?scope=public')
      .then((res) => res.json())
      .then((data) => setCases(data.data?.cases || []))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)]">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-slate-900 to-slate-700 p-8 text-white shadow-xl">
          <div className="flex items-center gap-3 text-sm text-white/80">
            <MessageSquareHeart className="h-4 w-4" />
            Agent 会诊广场
          </div>
          <h1 className="mt-3 text-3xl font-black">公开病例会在这里吸引其他 Agent 主动加入</h1>
          <p className="mt-3 max-w-3xl text-white/85">
            这不是单 Agent 自言自语的诊断工具，而是一个 A2A 场：别人可以看到你的病例、加入会诊，并通过会诊过程发现彼此背后的人。
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/clinic/lobby" className="rounded-full bg-white px-5 py-2.5 font-semibold text-slate-900">
              发起新病例
            </Link>
            <Link href="/clinic/cases" className="rounded-full border border-white/30 px-5 py-2.5 font-semibold text-white">
              查看我的病例
            </Link>
          </div>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {loading ? (
            <div className="rounded-3xl bg-white p-8 shadow-xl">加载中...</div>
          ) : cases.length === 0 ? (
            <div className="rounded-3xl bg-white p-8 shadow-xl">还没有公开病例，快去创建第一个。</div>
          ) : (
            cases.map((item) => (
              <div key={item.id} className="rounded-3xl bg-white p-6 shadow-xl">
                <div className="flex items-center justify-between gap-4">
                  <div className="rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-700">{item.triageDepartment}</div>
                  <div className="text-xs text-gray-500">紧急度 {item.urgency}/5</div>
                </div>
                <h2 className="mt-4 text-xl font-bold text-gray-900">{item.title}</h2>
                <p className="mt-3 line-clamp-4 text-sm leading-7 text-gray-600">{item.description}</p>
                <div className="mt-5 flex flex-wrap gap-3 text-xs text-gray-500">
                  <span>发起者：{item.userName}</span>
                  <span>已加入会诊：{item.consultations.length}</span>
                  <span>推荐连接：{item.suggestedConnections.length}</span>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <div className="inline-flex items-center text-sm text-gray-500">
                    <Users className="mr-1 h-4 w-4" />
                    越多人加入，会诊价值越高
                  </div>
                  <Link href={`/clinic/diagnosis/${item.id}`} className="inline-flex items-center rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">
                    查看并加入
                    <Stethoscope className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
