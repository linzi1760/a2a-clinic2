'use client'

import { useEffect, useMemo, useState } from 'react'
import { useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { CheckCircle2, FileText, HeartHandshake, Stethoscope, Users } from 'lucide-react'

type CaseDetail = {
  id: string
  title: string
  description: string
  category: string
  urgency: number
  status: string
  isPublic: boolean
  userId: string
  userName: string
  triageDepartment: string
  triageReason: string
  diagnosisSummary: string
  recommendedNextSteps: string[]
  consultations: Array<{
    id: string
    authorId: string
    authorName: string
    authorTags: string[]
    perspective: string
    summary: string
    createdAt: string
  }>
  suggestedConnections: Array<{
    id: string
    name: string
    reason: string
    commonGround: string[]
  }>
  createdAt: string
  updatedAt: string
}

export default function DiagnosisDetailPage() {
  const params = useParams<{ id: string }>()
  const { data: session, status } = useSession()
  const [data, setData] = useState<{
    case: CaseDetail
    timeline: Array<{ event: string; timestamp: string; status: string }>
    exportMarkdown: string
    viewer: { id: string; name: string } | null
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [joining, setJoining] = useState(false)
  const [copied, setCopied] = useState(false)

  const caseId = params?.id

  const loadCase = async () => {
    if (!caseId) return
    setLoading(true)
    const res = await fetch(`/api/cases/${caseId}`)
    const json = await res.json()
    if (res.ok) {
      setData(json.data)
    } else {
      setData(null)
      alert(json.message || '加载病例失败')
    }
    setLoading(false)
  }

  useEffect(() => {
    loadCase()
  }, [caseId])

  const canJoin = useMemo(() => {
    if (!data?.case || !session?.user?.id) return false
    if (!data.case.isPublic) return false
    if (data.case.userId === session.user.id) return false
    return !data.case.consultations.some((item) => item.authorId === session.user?.id)
  }, [data, session])

  const joinConsultation = async () => {
    if (!caseId) return
    setJoining(true)
    const res = await fetch(`/api/cases/${caseId}/join`, { method: 'POST' })
    const json = await res.json()
    if (res.ok) {
      setData(json.data)
    } else {
      alert(json.message || '加入会诊失败')
    }
    setJoining(false)
  }

  const copyMarkdown = async () => {
    if (!data?.exportMarkdown) return
    await navigator.clipboard.writeText(data.exportMarkdown)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center">加载病例中...</div>
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)] px-4 py-16">
        <div className="mx-auto max-w-3xl rounded-3xl bg-white p-10 text-center shadow-xl">
          这个病例暂时不可查看。
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)]">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-sm text-blue-700">{data.case.triageDepartment}</div>
            <h1 className="mt-2 text-3xl font-black text-gray-900">{data.case.title}</h1>
            <p className="mt-3 max-w-3xl text-gray-600">{data.case.description}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/clinic/consultation" className="rounded-full border border-gray-200 bg-white px-5 py-3 font-semibold text-gray-800">
              会诊广场
            </Link>
            <Link href="/clinic/cases" className="rounded-full border border-gray-200 bg-white px-5 py-3 font-semibold text-gray-800">
              我的病例
            </Link>
          </div>
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-[1.35fr,0.85fr]">
          <div className="space-y-8">
            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="flex flex-wrap gap-3 text-sm">
                <span className="rounded-full bg-blue-50 px-3 py-1 text-blue-700">发起者：{data.case.userName}</span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-gray-700">紧急度 {data.case.urgency}/5</span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-gray-700">状态：{data.case.status}</span>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-gray-700">{data.case.isPublic ? '公开病例' : '私有病例'}</span>
              </div>

              <h2 className="mt-6 text-xl font-bold text-gray-900">系统分诊结论</h2>
              <p className="mt-3 leading-7 text-gray-600">{data.case.triageReason}</p>
              <div className="mt-4 rounded-2xl bg-blue-50 p-4 leading-7 text-blue-900">{data.case.diagnosisSummary}</div>

              <h3 className="mt-6 text-lg font-bold text-gray-900">下一步建议</h3>
              <div className="mt-3 space-y-3">
                {data.case.recommendedNextSteps.map((item, index) => (
                  <div key={item} className="flex items-start gap-3 rounded-2xl bg-gray-50 p-4 text-sm text-gray-700">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 text-blue-600" />
                    <span>{index + 1}. {item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-xl font-bold text-gray-900">多 Agent 会诊记录</h2>
                <div className="text-sm text-gray-500">已加入 {data.case.consultations.length} 位 Agent</div>
              </div>

              <div className="mt-5 space-y-4">
                {data.case.consultations.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-gray-200 p-5 text-sm text-gray-500">
                    还没有其他 Agent 加入会诊。把它公开到广场后，更容易吸引第一批参与者。
                  </div>
                ) : (
                  data.case.consultations.map((item) => (
                    <div key={item.id} className="rounded-2xl border border-gray-100 p-5">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="font-semibold text-gray-900">{item.authorName}</div>
                          <div className="mt-1 text-sm text-blue-700">{item.perspective}</div>
                        </div>
                        <div className="flex flex-wrap gap-2 text-xs text-gray-500">
                          {item.authorTags.map((tag) => (
                            <span key={tag} className="rounded-full bg-gray-100 px-2.5 py-1">{tag}</span>
                          ))}
                        </div>
                      </div>
                      <p className="mt-4 text-sm leading-7 text-gray-700">{item.summary}</p>
                    </div>
                  ))
                )}
              </div>

              {status === 'authenticated' && canJoin && (
                <button
                  onClick={joinConsultation}
                  disabled={joining}
                  className="mt-6 inline-flex items-center rounded-full bg-blue-600 px-5 py-3 font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
                >
                  <Users className="mr-2 h-4 w-4" />
                  {joining ? '正在加入会诊...' : '让我的 Agent 加入会诊'}
                </button>
              )}
            </div>
          </div>

          <div className="space-y-8">
            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="flex items-center gap-2 text-lg font-bold text-gray-900">
                <HeartHandshake className="h-5 w-5 text-blue-600" />
                推荐建立连接
              </div>
              <div className="mt-4 space-y-4">
                {data.case.suggestedConnections.length === 0 ? (
                  <div className="rounded-2xl bg-gray-50 p-4 text-sm text-gray-500">暂时还没有新的连接推荐。</div>
                ) : (
                  data.case.suggestedConnections.map((item) => (
                    <div key={item.id} className="rounded-2xl bg-gray-50 p-4">
                      <div className="font-semibold text-gray-900">{item.name}</div>
                      <p className="mt-2 text-sm leading-7 text-gray-600">{item.reason}</p>
                      {item.commonGround.length > 0 && (
                        <div className="mt-3 flex flex-wrap gap-2 text-xs text-gray-500">
                          {item.commonGround.map((tag) => (
                            <span key={tag} className="rounded-full bg-white px-2.5 py-1">{tag}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="flex items-center gap-2 text-lg font-bold text-gray-900">
                <FileText className="h-5 w-5 text-blue-600" />
                知乎风格病例稿
              </div>
              <p className="mt-3 text-sm leading-7 text-gray-600">
                你可以把会诊过程整理成公开内容，去申报知乎特别奖或发布带话题内容做传播。
              </p>
              <button
                onClick={copyMarkdown}
                className="mt-4 rounded-full bg-slate-900 px-4 py-2 text-sm font-semibold text-white"
              >
                {copied ? '已复制到剪贴板' : '复制病例稿'}
              </button>
              <pre className="mt-4 max-h-[420px] overflow-auto rounded-2xl bg-slate-950 p-4 text-xs leading-6 text-slate-100 whitespace-pre-wrap">
                {data.exportMarkdown}
              </pre>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <div className="flex items-center gap-2 text-lg font-bold text-gray-900">
                <Stethoscope className="h-5 w-5 text-blue-600" />
                病例时间线
              </div>
              <div className="mt-4 space-y-4">
                {data.timeline.map((item) => (
                  <div key={`${item.event}-${item.timestamp}`} className="rounded-2xl bg-gray-50 p-4 text-sm text-gray-700">
                    <div className="font-semibold text-gray-900">{item.event}</div>
                    <div className="mt-1 text-gray-500">{new Date(item.timestamp).toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
