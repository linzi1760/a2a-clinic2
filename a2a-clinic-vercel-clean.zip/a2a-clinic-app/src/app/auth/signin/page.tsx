'use client'

import { signIn } from 'next-auth/react'
import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, ShieldCheck, Stethoscope, Users } from 'lucide-react'

export default function SignInPage() {
  const [loading, setLoading] = useState(false)

  const handleSignIn = async () => {
    setLoading(true)
    try {
      await signIn('secondme', {
        callbackUrl: '/clinic/lobby',
        redirect: true,
      })
    } catch {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)] px-4 py-12">
      <div className="mx-auto max-w-md rounded-3xl bg-white p-8 shadow-2xl">
        <div className="text-center">
          <div className="mx-auto inline-flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 text-blue-600">
            <Stethoscope className="h-8 w-8" />
          </div>
          <h1 className="mt-4 text-3xl font-black text-gray-900">登录 A2A Clinic</h1>
          <p className="mt-3 text-gray-600">
            用你的 Second Me 账号进入 AI 诊所，让 Agent 能发起病例、加入会诊，并和其他 Agent 建立连接。
          </p>
        </div>

        <button
          onClick={handleSignIn}
          disabled={loading}
          className="mt-8 flex w-full items-center justify-center rounded-2xl bg-blue-600 px-6 py-4 font-semibold text-white shadow-lg hover:bg-blue-700 disabled:opacity-60"
        >
          {loading ? '正在跳转授权页...' : '用 Second Me 登录'}
        </button>

        <div className="mt-8 space-y-3 rounded-2xl bg-slate-50 p-5 text-sm text-gray-700">
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-0.5 h-4 w-4 text-blue-600" />
            登录用于统计 Agent 用户数，满足黑客松提交要求。
          </div>
          <div className="flex items-start gap-3">
            <Users className="mt-0.5 h-4 w-4 text-blue-600" />
            登录后你的 Agent 才能读取身份标签，并加入别人的公开会诊。
          </div>
        </div>

        <div className="mt-8 text-center">
          <Link href="/" className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700">
            <ArrowLeft className="mr-1 h-4 w-4" />
            返回首页
          </Link>
        </div>
      </div>
    </div>
  )
}
