'use client'

import { useSearchParams } from 'next/navigation'
import { Suspense } from 'react'

function ErrorContent() {
  const searchParams = useSearchParams()
  const error = searchParams.get('error')

  const getErrorMessage = (errorCode: string | null) => {
    switch (errorCode) {
      case 'Configuration':
        return '服务器配置错误。请检查环境变量配置。'
      case 'AccessDenied':
        return '访问被拒绝。你可能取消了授权。'
      case 'Verification':
        return '验证失败。链接可能已过期。'
      case 'OAuthSignin':
        return 'OAuth登录过程错误。'
      case 'OAuthCallback':
        return 'OAuth回调错误。'
      case 'OAuthCreateAccount':
        return '无法创建OAuth账户。'
      case 'EmailCreateAccount':
        return '无法创建邮箱账户。'
      case 'Callback':
        return '回调错误。'
      case 'OAuthAccountNotLinked':
        return '账户未关联。'
      case 'EmailSignin':
        return '邮箱登录错误。'
      case 'CredentialsSignin':
        return '凭证登录错误。'
      case 'SessionRequired':
        return '需要登录会话。'
      default:
        return '发生了未知错误。'
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-red-500 to-orange-500 mb-4">
            <span className="text-2xl text-white">⚠️</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">登录错误</h1>
          <p className="text-gray-600 mt-2">登录过程中出现了问题</p>
        </div>

        <div className="space-y-6">
          {/* 错误信息 */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center mb-2">
              <span className="text-red-600 mr-2">❌</span>
              <h3 className="font-medium text-red-800">错误详情</h3>
            </div>
            <p className="text-red-700">
              {getErrorMessage(error)}
            </p>
            {error && (
              <p className="mt-2 text-sm text-red-600">
                错误代码: <code className="font-mono">{error}</code>
              </p>
            )}
          </div>

          {/* 解决方案 */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <h3 className="font-medium text-blue-800 mb-2">解决方案</h3>
            <ul className="text-sm text-blue-700 space-y-2">
              <li>• 检查Second Me应用是否已启用</li>
              <li>• 确认重定向URI配置正确</li>
              <li>• 检查Client ID/Secret是否正确</li>
              <li>• 清除浏览器缓存后重试</li>
              <li>• 联系技术支持</li>
            </ul>
          </div>

          {/* 操作按钮 */}
          <div className="space-y-3">
            <a
              href="/auth/signin"
              className="block w-full py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 text-center"
            >
              重新登录
            </a>
            <a
              href="/"
              className="block w-full py-3 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 text-center"
            >
              返回首页
            </a>
          </div>

          {/* 技术支持 */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-medium text-gray-900 mb-2">技术支持</h3>
            <div className="text-sm text-gray-600 space-y-1">
              <p>如果问题持续存在，请提供以下信息：</p>
              <ul className="list-disc list-inside ml-2">
                <li>错误代码</li>
                <li>浏览器控制台输出</li>
                <li>服务器日志</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>A2A Clinic - Agent智能诊所</p>
          <p className="mt-1">错误时间: {new Date().toLocaleString()}</p>
        </div>
      </div>
    </div>
  )
}

export default function ErrorPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="mb-4 inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="text-gray-600">加载错误信息...</p>
        </div>
      </div>
    }>
      <ErrorContent />
    </Suspense>
  )
}