'use client'

import Link from 'next/link'

export default function OAuthDebugPage() {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#eff6ff,white_45%,#f5f3ff)] px-4 py-16">
      <div className="mx-auto max-w-3xl rounded-3xl bg-white p-10 shadow-xl">
        <h1 className="text-3xl font-black text-gray-900">OAuth 调试页</h1>
        <p className="mt-4 leading-7 text-gray-600">
          这个页面保留给开发期排查登录问题使用。比赛演示时建议直接从首页或登录页进入，不需要向评委展示这里。
        </p>
        <div className="mt-8 space-y-3 text-sm text-gray-700">
          <p>• 请确认开发者平台的回调地址与当前部署地址一致。</p>
          <p>• 请确认环境变量中已配置 SECONDME_CLIENT_ID、SECONDME_CLIENT_SECRET、NEXTAUTH_URL。</p>
          <p>• 如果登录失败，优先查看 /auth/error 页面给出的错误类型。</p>
        </div>
        <div className="mt-8 flex gap-3">
          <Link href="/auth/signin" className="rounded-full bg-blue-600 px-5 py-3 font-semibold text-white hover:bg-blue-700">
            回到登录页
          </Link>
          <Link href="/" className="rounded-full border border-gray-200 px-5 py-3 font-semibold text-gray-800 hover:bg-gray-50">
            返回首页
          </Link>
        </div>
      </div>
    </div>
  )
}
