'use client'

import { signIn, useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'

export default function QuickTestPage() {
  const { data: session, status } = useSession()
  const [configInfo, setConfigInfo] = useState<any>(null)

  useEffect(() => {
    // 获取配置信息（不包含敏感信息）
    const info = {
      hasClientId: !!process.env.NEXT_PUBLIC_SECONDME_CLIENT_ID,
      hasClientSecret: !!process.env.SECONDME_CLIENT_SECRET,
      apiBase: process.env.SECONDME_API_BASE,
      nodeEnv: process.env.NODE_ENV,
      timestamp: new Date().toISOString(),
    }
    setConfigInfo(info)
  }, [])

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="mb-4 inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="text-gray-600">检查会话状态...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 mb-4">
              <span className="text-2xl text-white">🔧</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900">A2A Clinic 配置测试</h1>
            <p className="text-gray-600 mt-2">验证 Second Me OAuth 配置</p>
          </div>

          {/* 配置信息 */}
          <div className="mb-8 bg-gray-50 rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">配置状态</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-700">Client ID:</span>
                <span className={`font-medium ${configInfo?.hasClientId ? 'text-green-600' : 'text-red-600'}`}>
                  {configInfo?.hasClientId ? '✅ 已配置' : '❌ 未配置'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700">Client Secret:</span>
                <span className={`font-medium ${configInfo?.hasClientSecret ? 'text-green-600' : 'text-red-600'}`}>
                  {configInfo?.hasClientSecret ? '✅ 已配置' : '❌ 未配置'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700">API Base:</span>
                <span className="font-mono text-sm text-blue-600">
                  {configInfo?.apiBase || '未配置'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700">环境:</span>
                <span className="font-medium text-gray-900">{configInfo?.nodeEnv}</span>
              </div>
            </div>
          </div>

          {/* 登录状态 */}
          <div className="mb-8 bg-blue-50 rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">登录状态</h2>
            {!session ? (
              <div className="text-center py-4">
                <p className="text-gray-700 mb-4">你还没有登录</p>
                <button
                  onClick={() => signIn('secondme')}
                  className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:opacity-90 transition-opacity"
                >
                  <span className="mr-2">🔐</span>
                  用 Second Me 登录
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-green-400 to-blue-500 flex items-center justify-center mr-3">
                      <span className="text-white">👤</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{session.user?.name}</h3>
                      <p className="text-sm text-gray-600">{session.user?.email}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mt-4">
                    <div className="bg-green-50 rounded-lg p-3">
                      <div className="text-sm text-green-800">Access Token</div>
                      <div className="text-xs font-mono truncate">
                        {session.accessToken ? '✅ 已获取' : '❌ 未获取'}
                      </div>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-3">
                      <div className="text-sm text-blue-800">登录时间</div>
                      <div className="text-xs">
                        {new Date(session.expires || '').toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <a
                    href="/test-login"
                    className="inline-block px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700"
                  >
                    🧪 测试 API 功能
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* 测试步骤 */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">测试步骤</h2>
            <ol className="list-decimal list-inside space-y-3 text-gray-700">
              <li>点击上方"用 Second Me 登录"按钮</li>
              <li>在Second Me授权页面登录并授权</li>
              <li>返回此页面查看登录状态</li>
              <li>点击"测试 API 功能"进行完整测试</li>
              <li>访问 <a href="/" className="text-blue-600 hover:underline">主页</a> 开始使用</li>
            </ol>
          </div>

          {/* 技术支持 */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="text-center text-sm text-gray-500">
              <p>遇到问题？请检查：</p>
              <ul className="mt-2 space-y-1">
                <li>• Client ID/Secret 是否正确配置</li>
                <li>• 重定向URI是否为: http://localhost:3000/api/auth/callback</li>
                <li>• Second Me 应用是否已启用</li>
              </ul>
              <p className="mt-4">测试时间: {configInfo?.timestamp ? new Date(configInfo.timestamp).toLocaleString() : ''}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}