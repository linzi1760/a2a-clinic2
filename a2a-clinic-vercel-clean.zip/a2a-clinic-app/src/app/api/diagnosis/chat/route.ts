import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../auth/[...nextauth]/route'
import { getSecondMeAPI } from '@/lib/secondme'

const DIAGNOSIS_SYSTEM_PROMPT = `你是 A2A Clinic 的会诊助手。
你的任务不是代替用户完成所有工作，而是帮助发起病例的 Agent：
1. 澄清问题
2. 提出分步骤建议
3. 鼓励公开会诊与多 Agent 协作
4. 把结论整理成易于沉淀的结构`

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.accessToken) {
      return NextResponse.json({ error: '未登录', message: '请先使用 Second Me 登录。' }, { status: 401 })
    }

    const { message, caseId, sessionId, enableWebSearch } = await request.json()
    if (!message) {
      return NextResponse.json({ error: '缺少参数', message: '请提供 message。' }, { status: 400 })
    }

    const secondMe = getSecondMeAPI(session.accessToken)
    const encoder = new TextEncoder()

    const stream = new ReadableStream({
      async start(controller) {
        try {
          let finalSessionId = sessionId
          let fullResponse = ''

          const generator = secondMe.converseWithAgentStream(message, {
            sessionId,
            enableWebSearch: Boolean(enableWebSearch),
            systemPrompt: DIAGNOSIS_SYSTEM_PROMPT,
          })

          for await (const chunk of generator) {
            if (chunk.type === 'session') {
              finalSessionId = chunk.data?.sessionId || finalSessionId
              controller.enqueue(
                encoder.encode(
                  `event: session\ndata: ${JSON.stringify({ sessionId: finalSessionId, caseId, timestamp: new Date().toISOString() })}\n\n`
                )
              )
            } else if (chunk.type === 'tool_call') {
              controller.enqueue(encoder.encode(`event: tool_call\ndata: ${JSON.stringify(chunk.data)}\n\n`))
            } else if (chunk.type === 'tool_result') {
              controller.enqueue(encoder.encode(`event: tool_result\ndata: ${JSON.stringify(chunk.data)}\n\n`))
            } else if (chunk.type === 'content' && chunk.content) {
              fullResponse += chunk.content
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: chunk.content })}\n\n`))
            } else if (chunk.type === 'done') {
              if (caseId && fullResponse) {
                try {
                  await secondMe.reportAgentMemory(
                    {
                      kind: 'diagnosis_case',
                      id: caseId,
                      meta: { type: 'a2a_clinic_case' },
                    },
                    'diagnosis_completed',
                    [{ objectType: 'diagnosis_case', objectId: caseId, contentPreview: fullResponse.slice(0, 120) }],
                    {
                      actionLabel: '完成了一轮病例诊断',
                      displayText: `A2A Clinic 完成了病例 ${caseId} 的一轮诊断`,
                      importance: 0.7,
                    }
                  )
                } catch {
                  // Memory 上报失败时不影响主流程
                }
              }

              controller.enqueue(encoder.encode('data: [DONE]\n\n'))
            }
          }

          controller.close()
        } catch (error: any) {
          controller.enqueue(encoder.encode(`event: error\ndata: ${JSON.stringify({ error: error.message || '诊断失败' })}\n\n`))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: '诊断对话失败',
        message: error.message || '未知错误',
      },
      { status: 500 }
    )
  }
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.accessToken) {
      return NextResponse.json({ error: '未登录', message: '请先使用 Second Me 登录。' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const caseId = searchParams.get('caseId')
    const secondMe = getSecondMeAPI(session.accessToken)
    const sessions = await secondMe.getChatSessions('a2a-clinic')

    let caseMessages: any[] = []
    if (caseId) {
      const relevant = sessions.find((item) => item.lastMessage?.includes(caseId) || item.sessionId.includes(caseId))
      if (relevant) {
        const messages = await secondMe.getChatMessages(relevant.sessionId)
        caseMessages = messages.messages || []
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        totalSessions: sessions.length,
        sessions,
        caseMessages,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    return NextResponse.json({ success: false, error: '获取诊断历史失败', message: error.message || '未知错误' }, { status: 500 })
  }
}
