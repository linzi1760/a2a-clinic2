import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'
import { getSecondMeAPI } from '@/lib/secondme'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.accessToken) {
      return NextResponse.json(
        { error: '未登录', message: '请先使用Second Me登录' },
        { status: 401 }
      )
    }

    const secondMe = getSecondMeAPI(session.accessToken as string)
    
    // 测试1: 获取用户信息
    const userInfo = await secondMe.getUserInfo()
    
    // 测试2: 获取兴趣标签
    const shades = await secondMe.getUserShades()
    
    // 测试3: 获取软记忆（个人知识库）
    const softMemory = await secondMe.getSoftMemory(undefined, 1, 5)
    
    // 测试4: 获取聊天会话列表
    const chatSessions = await secondMe.getChatSessions('general')
    
    return NextResponse.json({
      success: true,
      message: 'Second Me API测试成功',
      user: {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        bio: userInfo.bio,
        profileCompleteness: userInfo.profileCompleteness,
      },
      interests: shades.map(s => ({
        name: s.shadeName,
        confidence: s.confidenceLevel,
        description: s.shadeDescription,
      })),
      knowledgeBase: {
        total: softMemory.total,
        recent: softMemory.list.map(item => ({
          category: item.factObject,
          content: item.factContent,
          updated: new Date(item.updateTime).toLocaleDateString(),
        })),
      },
      chatSessions: chatSessions.map(s => ({
        id: s.sessionId,
        lastMessage: s.lastMessage,
        messageCount: s.messageCount,
        lastUpdate: s.lastUpdateTime,
      })),
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    console.error('Second Me API测试错误:', error)
    
    return NextResponse.json({
      success: false,
      error: 'API测试失败',
      message: error.message || '未知错误',
      details: error.response?.data || error.toString(),
      timestamp: new Date().toISOString(),
    }, { status: 500 })
  }
}

// 测试流式对话
export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.accessToken) {
      return NextResponse.json(
        { error: '未登录', message: '请先使用Second Me登录' },
        { status: 401 }
      )
    }

    const { message, enableWebSearch } = await request.json()
    
    if (!message) {
      return NextResponse.json(
        { error: '缺少参数', message: '请提供message参数' },
        { status: 400 }
      )
    }

    const secondMe = getSecondMeAPI(session.accessToken as string)
    
    // 创建流式响应
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const streamGenerator = secondMe.converseWithAgentStream(message, {
            enableWebSearch: enableWebSearch || false,
            systemPrompt: '你是一个专业的AI问题诊断专家。请以友好、专业的态度帮助用户分析他们遇到的问题。',
          })
          
          for await (const chunk of streamGenerator) {
            if (chunk.type === 'session') {
              controller.enqueue(encoder.encode(`event: session\ndata: ${JSON.stringify(chunk.data)}\n\n`))
            } else if (chunk.type === 'tool_call') {
              controller.enqueue(encoder.encode(`event: tool_call\ndata: ${JSON.stringify(chunk.data)}\n\n`))
            } else if (chunk.type === 'tool_result') {
              controller.enqueue(encoder.encode(`event: tool_result\ndata: ${JSON.stringify(chunk.data)}\n\n`))
            } else if (chunk.type === 'content' && chunk.content) {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: chunk.content })}\n\n`))
            } else if (chunk.type === 'done') {
              controller.enqueue(encoder.encode('data: [DONE]\n\n'))
            }
          }
          
          controller.close()
        } catch (error: any) {
          console.error('流式对话错误:', error)
          controller.enqueue(encoder.encode(`event: error\ndata: ${JSON.stringify({ error: error.message })}\n\n`))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (error: any) {
    console.error('流式对话API错误:', error)
    
    return NextResponse.json({
      success: false,
      error: '流式对话失败',
      message: error.message || '未知错误',
    }, { status: 500 })
  }
}