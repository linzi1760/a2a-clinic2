import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'
import { cookies } from 'next/headers'

// 开发环境下的模拟会话检查
async function getDevSession() {
  if (process.env.NODE_ENV !== 'development') {
    return null
  }
  
  try {
    const cookieStore = await cookies()
    const devSession = cookieStore.get('dev-session')
    
    if (!devSession) {
      return null
    }
    
    return JSON.parse(devSession.value)
  } catch (error) {
    console.error('获取开发会话错误:', error)
    return null
  }
}

export async function GET() {
  try {
    // 首先尝试获取NextAuth会话
    const session = await getServerSession(authOptions)
    
    if (session) {
      return NextResponse.json({
        success: true,
        message: 'API测试成功 (Second Me登录)',
        user: {
          id: session.user?.id,
          name: session.user?.name,
          email: session.user?.email,
          avatar: session.user?.image,
        },
        authType: 'secondme',
        timestamp: new Date().toISOString(),
      })
    }
    
    // 开发环境下尝试获取模拟会话
    if (process.env.NODE_ENV === 'development') {
      const devUser = await getDevSession()
      
      if (devUser) {
        return NextResponse.json({
          success: true,
          message: 'API测试成功 (开发环境模拟登录)',
          user: devUser,
          authType: 'dev',
          warning: '⚠️ 这是开发环境下的模拟登录，生产环境请使用Second Me OAuth',
          timestamp: new Date().toISOString(),
        })
      }
    }
    
    // 未登录
    return NextResponse.json(
      { error: '未登录', message: '请先使用Second Me登录' },
      { status: 401 }
    )
    
  } catch (error) {
    console.error('API测试错误:', error)
    return NextResponse.json(
      { error: '服务器错误', message: error instanceof Error ? error.message : '未知错误' },
      { status: 500 }
    )
  }
}