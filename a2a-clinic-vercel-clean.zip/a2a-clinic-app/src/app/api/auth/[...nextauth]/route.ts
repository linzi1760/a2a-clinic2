import NextAuth, { NextAuthOptions } from 'next-auth'
import SecondMeProvider from './secondme-provider'

async function fetchShades(accessToken: string) {
  try {
    const response = await fetch('https://api.mindverse.com/gate/lab/api/secondme/user/shades', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (!response.ok) return []
    const data = await response.json()
    return (data.data?.shades || data.shades || []).map((item: any) => item.shadeName).filter(Boolean)
  } catch {
    return []
  }
}

export const authOptions: NextAuthOptions = {
  providers: [
    SecondMeProvider({
      clientId: process.env.SECONDME_CLIENT_ID!,
      clientSecret: process.env.SECONDME_CLIENT_SECRET!,
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      if (account) {
        const accessToken = (account.access_token || account.accessToken) as string | undefined
        token.accessToken = accessToken
        token.refreshToken = (account.refresh_token || account.refreshToken) as string | undefined
        token.accessTokenExpires = account.expires_at ? account.expires_at * 1000 : Date.now() + 3600 * 1000

        const interests = accessToken ? await fetchShades(accessToken) : []
        token.user = {
          id: (profile as any)?.userId || (profile as any)?.id || token.sub,
          name: profile?.name || 'Second Me 用户',
          email: profile?.email || null,
          image: (profile as any)?.avatar || null,
          interests,
          expertise: interests.slice(0, 3),
        }
      }

      if (token.accessTokenExpires && Date.now() < token.accessTokenExpires) {
        return token
      }

      if (token.refreshToken) {
        return refreshAccessToken(token)
      }

      return token
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken
      session.error = token.error
      session.user = {
        ...session.user,
        ...token.user,
      }
      return session
    },
  },
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60,
  },
  debug: false,
}

async function refreshAccessToken(token: any) {
  try {
    const response = await fetch('https://api.mindverse.com/gate/lab/api/oauth/token/refresh', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: token.refreshToken as string,
        client_id: process.env.SECONDME_CLIENT_ID!,
        client_secret: process.env.SECONDME_CLIENT_SECRET!,
      }),
    })

    const data = await response.json()
    if (!response.ok) {
      throw new Error(JSON.stringify(data))
    }

    const refreshed = data.data || data
    return {
      ...token,
      accessToken: refreshed.accessToken || refreshed.access_token,
      accessTokenExpires: Date.now() + Number(refreshed.expiresIn || refreshed.expires_in || 3600) * 1000,
      refreshToken: refreshed.refreshToken || refreshed.refresh_token || token.refreshToken,
      error: undefined,
    }
  } catch {
    return {
      ...token,
      error: 'RefreshAccessTokenError',
    }
  }
}

const handler = NextAuth(authOptions)

export { handler as GET, handler as POST }
