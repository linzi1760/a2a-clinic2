import type { OAuthConfig, OAuthUserConfig } from 'next-auth/providers/oauth'

export interface SecondMeProfile {
  id: string
  name: string
  email?: string
  avatar?: string
  interests: string[]
  expertise: string[]
}

export default function SecondMeProvider(
  options: OAuthUserConfig<SecondMeProfile>
): OAuthConfig<SecondMeProfile> {
  return {
    id: 'secondme',
    name: 'Second Me',
    type: 'oauth',
    version: '2.0',
    authorization: {
      url: 'https://go.second.me/oauth/',
      params: {
        scope: 'user.info user.info.shades chat',
        response_type: 'code',
      },
    },
    token: {
      url: 'https://api.mindverse.com/gate/lab/api/oauth/token/code',
      async request(context: any) {
        const response = await fetch(context.provider.token?.url as string, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            grant_type: 'authorization_code',
            code: context.params.code || '',
            redirect_uri: context.provider.callbackUrl,
            client_id: context.provider.clientId || '',
            client_secret: context.provider.clientSecret || '',
          }),
        })

        const data = await response.json()
        if (!response.ok) {
          throw new Error(`Token 请求失败：${JSON.stringify(data)}`)
        }

        const tokens = data.data || data
        const expiresIn = Number(tokens.expiresIn || tokens.expires_in || 3600)

        return {
          tokens: {
            access_token: tokens.accessToken || tokens.access_token,
            refresh_token: tokens.refreshToken || tokens.refresh_token,
            expires_at: Math.floor(Date.now() / 1000) + expiresIn,
            token_type: tokens.tokenType || tokens.token_type || 'Bearer',
          },
        }
      },
    },
    userinfo: {
      url: 'https://api.mindverse.com/gate/lab/api/secondme/user/info',
      async request(context: any) {
        const response = await fetch(context.provider.userinfo?.url as string, {
          headers: {
            Authorization: `Bearer ${context.tokens.access_token}`,
          },
        })

        const data = await response.json()
        if (!response.ok) {
          throw new Error(`用户信息请求失败：${JSON.stringify(data)}`)
        }

        return data.data || data
      },
    },
    profile(profile: any) {
      return {
        id: profile.userId || profile.id || profile.sub || `user-${Date.now()}`,
        name: profile.name || profile.username || 'Second Me 用户',
        email: profile.email || null,
        image: profile.avatar || profile.picture || null,
        interests: profile.interests || [],
        expertise: profile.expertise || [],
      }
    },
    checks: ['pkce', 'state'],
    options,
  }
}
