import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'

export async function GET() {
  try {
    // 检查会话
    const session = await getServerSession(authOptions)
    
    // 返回配置信息（不包含敏感信息）
    const config = {
      hasClientId: !!process.env.SECONDME_CLIENT_ID,
      hasClientSecret: !!process.env.SECONDME_CLIENT_SECRET,
      apiBase: process.env.SECONDME_API_BASE,
      nextAuthSecret: !!process.env.NEXTAUTH_SECRET,
      nodeEnv: process.env.NODE_ENV,
      isLoggedIn: !!session,
      user: session?.user ? {
        name: session.user.name,
        email: session.user.email,
        hasAccessToken: !!session.accessToken,
      } : null,
      timestamp: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      message: '配置检查完成',
      config,
      suggestions: !config.hasClientSecret ? [
        '请检查 .env.local 文件中的 SECONDME_CLIENT_SECRET',
        '确保 Client Secret 已正确配置',
        '重启开发服务器: npm run dev'
      ] : [],
    })
  } catch (error: any) {
    console.error('配置检查错误:', error)
    
    return NextResponse.json({
      success: false,
      error: '配置检查失败',
      message: error.message || '未知错误',
      timestamp: new Date().toISOString(),
    }, { status: 500 })
  }
}

// 测试OAuth回调
export async function POST(request: Request) {
  try {
    const { action } = await request.json()
    
    if (action === 'test-redirect') {
      // 返回OAuth重定向信息
      const redirectUri = 'http://localhost:3000/api/auth/callback'
      const authUrl = `https://develop.second.me/oauth/authorize?client_id=${process.env.SECONDME_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=openid%20profile%20email%20agent:converse%20memory:read%20memory:write`
      
      return NextResponse.json({
        success: true,
        redirectUri,
        authUrl,
        clientId: process.env.SECONDME_CLIENT_ID?.substring(0, 8) + '...',
        timestamp: new Date().toISOString(),
      })
    }
    
    return NextResponse.json({
      success: false,
      error: '未知操作',
      message: '请指定有效的action参数',
    }, { status: 400 })
  } catch (error: any) {
    console.error('OAuth测试错误:', error)
    
    return NextResponse.json({
      success: false,
      error: 'OAuth测试失败',
      message: error.message || '未知错误',
    }, { status: 500 })
  }
}