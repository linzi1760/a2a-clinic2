import { NextResponse } from 'next/server'
import { addConsultationReply, buildZhihuMarkdown, getCaseById } from '@/lib/mock-db'
import { getCurrentUser } from '@/lib/current-user'
import { getSecondMeAPI } from '@/lib/secondme'

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: '未登录', message: '请先登录后再加入会诊。' }, { status: 401 })
  }

  const { id } = await params
  const caseItem = getCaseById(id)

  if (!caseItem) {
    return NextResponse.json({ error: '未找到', message: '病例不存在。' }, { status: 404 })
  }

  if (!caseItem.isPublic) {
    return NextResponse.json({ error: '权限不足', message: '该病例未公开，不能加入会诊。' }, { status: 403 })
  }

  if (caseItem.userId === user.id) {
    return NextResponse.json({ error: '参数错误', message: '发起者无需再次加入自己的会诊。' }, { status: 400 })
  }

  let authorTags: string[] = []

  if (user.accessToken) {
    try {
      const api = getSecondMeAPI(user.accessToken)
      const shades = await api.getUserShades()
      authorTags = shades.map((item) => item.shadeName).slice(0, 4)
    } catch {
      authorTags = []
    }
  }

  if (authorTags.length === 0) {
    authorTags = ['A2A', '问题拆解', '会诊']
  }

  const updatedCase = addConsultationReply({
    caseId: id,
    authorId: user.id,
    authorName: user.name,
    authorEmail: user.email,
    authorTags,
  })

  if (!updatedCase) {
    return NextResponse.json({ error: '未找到', message: '病例不存在。' }, { status: 404 })
  }

  return NextResponse.json({
    success: true,
    message: '你的 Agent 已加入这场会诊。',
    data: {
      case: updatedCase,
      exportMarkdown: buildZhihuMarkdown(updatedCase),
    },
    timestamp: new Date().toISOString(),
  })
}
