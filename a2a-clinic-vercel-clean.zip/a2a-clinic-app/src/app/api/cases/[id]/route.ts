import { NextResponse } from 'next/server'
import { buildTimeline, buildZhihuMarkdown, getCaseById } from '@/lib/mock-db'
import { getCurrentUser } from '@/lib/current-user'

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const caseItem = getCaseById(id)

  if (!caseItem) {
    return NextResponse.json({ error: '未找到', message: '病例不存在。' }, { status: 404 })
  }

  const user = await getCurrentUser()
  const canView = caseItem.isPublic || user?.id === caseItem.userId

  if (!canView) {
    return NextResponse.json({ error: '权限不足', message: '这是一个私有病例。' }, { status: 403 })
  }

  return NextResponse.json({
    success: true,
    data: {
      case: caseItem,
      timeline: buildTimeline(caseItem),
      exportMarkdown: buildZhihuMarkdown(caseItem),
      viewer: user
        ? {
            id: user.id,
            name: user.name,
          }
        : null,
    },
    timestamp: new Date().toISOString(),
  })
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: '未登录', message: '请先登录。' }, { status: 401 })
  }

  const { id } = await params
  const caseItem = getCaseById(id)
  if (!caseItem) {
    return NextResponse.json({ error: '未找到', message: '病例不存在。' }, { status: 404 })
  }

  if (caseItem.userId !== user.id) {
    return NextResponse.json({ error: '权限不足', message: '只能更新自己的病例。' }, { status: 403 })
  }

  const body = await request.json()
  if (typeof body.status === 'string' && ['pending', 'consulting', 'resolved'].includes(body.status)) {
    caseItem.status = body.status
  }

  if (typeof body.isPublic === 'boolean') {
    caseItem.isPublic = body.isPublic
  }

  caseItem.updatedAt = new Date().toISOString()

  return NextResponse.json({
    success: true,
    data: {
      case: caseItem,
    },
    timestamp: new Date().toISOString(),
  })
}
