import { NextResponse } from 'next/server'
import { createCase, listPublicCases, listUserCases } from '@/lib/mock-db'
import { getCurrentUser } from '@/lib/current-user'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const scope = searchParams.get('scope')

  if (scope === 'public') {
    const cases = listPublicCases()
    return NextResponse.json({
      success: true,
      data: {
        cases,
        total: cases.length,
      },
      timestamp: new Date().toISOString(),
    })
  }

  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: '未登录', message: '请先登录后查看我的病例。' }, { status: 401 })
  }

  const cases = listUserCases(user.id)
  return NextResponse.json({
    success: true,
    data: {
      cases,
      total: cases.length,
    },
    timestamp: new Date().toISOString(),
  })
}

export async function POST(request: Request) {
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: '未登录', message: '请先使用 Second Me 登录。' }, { status: 401 })
  }

  const body = await request.json()
  const { title, description, category, urgency, tags, isPublic } = body

  if (!title || !description || !category) {
    return NextResponse.json({ error: '参数错误', message: '标题、描述、分类为必填项。' }, { status: 400 })
  }

  const validCategories = ['technical', 'academic', 'creative', 'life']
  if (!validCategories.includes(category)) {
    return NextResponse.json({ error: '参数错误', message: '分类不合法。' }, { status: 400 })
  }

  const newCase = createCase({
    title,
    description,
    category,
    urgency: Number(urgency) || 3,
    isPublic: Boolean(isPublic),
    tags: Array.isArray(tags) ? tags : [],
    userId: user.id,
    userName: user.name,
    userEmail: user.email,
  })

  return NextResponse.json(
    {
      success: true,
      message: newCase.isPublic ? '病例已创建，并已进入公开会诊广场。' : '病例已创建，当前仅你自己可见。',
      data: {
        case: newCase,
        nextSteps: newCase.recommendedNextSteps,
      },
      timestamp: new Date().toISOString(),
    },
    { status: 201 }
  )
}
