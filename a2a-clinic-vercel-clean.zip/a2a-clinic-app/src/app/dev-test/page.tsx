'use client'

import { useState, useEffect } from 'react'

export default function DevTestPage() {
  const [user, setUser] = useState<any>(null)
  const [cases, setCases] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [newCase, setNewCase] = useState({
    title: '',
    description: '',
    category: 'technical',
    urgency: 3,
    tags: '',
  })

  // 检查登录状态
  const checkLogin = async () => {
    try {
      const response = await fetch('/api/test')
      const data = await response.json()
      
      if (response.ok) {
        setUser(data.user)
        setMessage(`已登录: ${data.user.name} (${data.authType})`)
      } else {
        setUser(null)
        setMessage('未登录')
      }
    } catch (error) {
      console.error('检查登录错误:', error)
      setMessage('检查登录失败')
    }
  }

  // 开发环境登录
  const devLogin = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/auth/dev-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username: '开发者测试' }),
      })
      const data = await response.json()
      
      if (response.ok) {
        setUser(data.user)
        setMessage(`开发登录成功: ${data.user.name}`)
      } else {
        setMessage(`登录失败: ${data.message}`)
      }
    } catch (error) {
      console.error('开发登录错误:', error)
      setMessage('开发登录失败')
    } finally {
      setLoading(false)
    }
  }

  // 开发环境登出
  const devLogout = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/auth/dev-login', {
        method: 'DELETE',
      })
      const data = await response.json()
      
      if (response.ok) {
        setUser(null)
        setCases([])
        setMessage('开发登出成功')
      } else {
        setMessage(`登出失败: ${data.message}`)
      }
    } catch (error) {
      console.error('开发登出错误:', error)
      setMessage('开发登出失败')
    } finally {
      setLoading(false)
    }
  }

  // 获取病例列表
  const fetchCases = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/cases')
      const data = await response.json()
      
      if (response.ok) {
        setCases(data.data.cases || [])
        setMessage(`获取到 ${data.data.total} 个病例`)
      } else {
        setMessage(`获取病例失败: ${data.message}`)
      }
    } catch (error) {
      console.error('获取病例错误:', error)
      setMessage('获取病例失败')
    } finally {
      setLoading(false)
    }
  }

  // 提交新病例
  const submitCase = async () => {
    if (!newCase.title || !newCase.description) {
      setMessage('请填写标题和描述')
      return
    }

    setLoading(true)
    try {
      const response = await fetch('/api/cases', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newCase,
          tags: newCase.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
        }),
      })
      const data = await response.json()
      
      if (response.ok) {
        setMessage(`病例提交成功: ${data.data.case.title}`)
        setNewCase({
          title: '',
          description: '',
          category: 'technical',
          urgency: 3,
          tags: '',
        })
        fetchCases() // 刷新列表
      } else {
        setMessage(`提交失败: ${data.message}`)
      }
    } catch (error) {
      console.error('提交病例错误:', error)
      setMessage('提交病例失败')
    } finally {
      setLoading(false)
    }
  }

  // 组件加载时检查登录状态
  useEffect(() => {
    checkLogin()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">A2A Clinic 开发测试</h1>
        
        {/* 状态信息 */}
        <div className="mb-8 p-4 bg-white rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold text-gray-800">系统状态</h2>
              <p className="text-gray-600">{message}</p>
            </div>
            <div className="flex space-x-4">
              {user ? (
                <>
                  <button
                    onClick={devLogout}
                    disabled={loading}
                    className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 disabled:opacity-50"
                  >
                    开发登出
                  </button>
                  <button
                    onClick={fetchCases}
                    disabled={loading}
                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                  >
                    刷新病例
                  </button>
                </>
              ) : (
                <button
                  onClick={devLogin}
                  disabled={loading}
                  className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
                >
                  开发登录
                </button>
              )}
            </div>
          </div>
          
          {user && (
            <div className="p-3 bg-blue-50 rounded border border-blue-200">
              <p className="text-blue-800">
                <strong>用户:</strong> {user.name} ({user.email})
              </p>
              <p className="text-blue-800 text-sm mt-1">
                <strong>ID:</strong> {user.id}
              </p>
            </div>
          )}
        </div>

        {/* 病例提交表单 */}
        {user && (
          <div className="mb-8 p-6 bg-white rounded-lg shadow">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">提交新病例</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  标题 *
                </label>
                <input
                  type="text"
                  value={newCase.title}
                  onChange={(e) => setNewCase({ ...newCase, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="例如：我的Agent无法正确解析JSON"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  描述 *
                </label>
                <textarea
                  value={newCase.description}
                  onChange={(e) => setNewCase({ ...newCase, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={4}
                  placeholder="详细描述您的问题..."
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    分类
                  </label>
                  <select
                    value={newCase.category}
                    onChange={(e) => setNewCase({ ...newCase, category: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="technical">技术问题</option>
                    <option value="academic">学术问题</option>
                    <option value="creative">创意问题</option>
                    <option value="life">生活问题</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    紧急程度 (1-5)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    value={newCase.urgency}
                    onChange={(e) => setNewCase({ ...newCase, urgency: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  标签 (逗号分隔)
                </label>
                <input
                  type="text"
                  value={newCase.tags}
                  onChange={(e) => setNewCase({ ...newCase, tags: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="例如：JSON, 解析, API"
                />
              </div>
              
              <button
                onClick={submitCase}
                disabled={loading || !newCase.title || !newCase.description}
                className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium rounded hover:opacity-90 disabled:opacity-50"
              >
                {loading ? '提交中...' : '提交病例'}
              </button>
            </div>
          </div>
        )}

        {/* 病例列表 */}
        {user && cases.length > 0 && (
          <div className="p-6 bg-white rounded-lg shadow">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              我的病例 ({cases.length})
            </h2>
            
            <div className="space-y-4">
              {cases.map((caseItem) => (
                <div key={caseItem.id} className="p-4 border border-gray-200 rounded hover:bg-gray-50">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium text-gray-900">{caseItem.title}</h3>
                    <span className={`px-2 py-1 text-xs rounded ${
                      caseItem.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      caseItem.status === 'diagnosing' ? 'bg-blue-100 text-blue-800' :
                      caseItem.status === 'resolved' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {caseItem.status === 'pending' ? '等待中' :
                       caseItem.status === 'diagnosing' ? '诊断中' :
                       caseItem.status === 'resolved' ? '已解决' : '已关闭'}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-2">{caseItem.description}</p>
                  
                  <div className="flex items-center text-sm text-gray-500">
                    <span className="mr-4">
                      <strong>分类:</strong> {caseItem.category}
                    </span>
                    <span className="mr-4">
                      <strong>紧急程度:</strong> {caseItem.urgency}/5
                    </span>
                    <span>
                      <strong>提交时间:</strong> {new Date(caseItem.createdAt).toLocaleString()}
                    </span>
                  </div>
                  
                  {caseItem.tags && caseItem.tags.length > 0 && (
                    <div className="mt-2">
                      <span className="text-sm text-gray-500">标签: </span>
                      {caseItem.tags.map((tag: string, index: number) => (
                        <span key={index} className="inline-block px-2 py-1 mr-1 text-xs bg-gray-100 text-gray-700 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* API测试 */}
        <div className="mt-8 p-6 bg-white rounded-lg shadow">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">API测试</h2>
          
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={checkLogin}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
            >
              测试 /api/test
            </button>
            
            <button
              onClick={fetchCases}
              disabled={!user}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 disabled:opacity-50"
            >
              测试 /api/cases
            </button>
          </div>
          
          <div className="mt-4 p-3 bg-gray-50 rounded text-sm">
            <p className="text-gray-700">
              <strong>注意:</strong> 这是开发环境测试页面。生产环境请使用正式的Second Me登录。
            </p>
            <p className="text-gray-600 mt-1">
              当前环境: <code className="px-1 bg-gray-200 rounded">{process.env.NODE_ENV}</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}