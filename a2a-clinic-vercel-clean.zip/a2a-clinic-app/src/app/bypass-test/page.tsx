'use client'

import { useState } from 'react'

export default function BypassTestPage() {
  const [testResult, setTestResult] = useState<string>('')
  const [loading, setLoading] = useState(false)

  const testDirectOAuth = async () => {
    setLoading(true)
    setTestResult('测试中...\n')
    
    try {
      // 测试不同的配置
      const tests = [
        {
          name: '最小scope测试',
          url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid'
        },
        {
          name: '基础scope测试',
          url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid%20profile%20email'
        },
        {
          name: '完整scope测试',
          url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid%20profile%20email%20agent%3Aconverse%20memory%3Aread%20memory%3Awrite'
        }
      ]

      let result = 'OAuth 直接测试结果:\n\n'
      
      for (const test of tests) {
        result += `🔍 ${test.name}:\n`
        result += `URL: ${test.url}\n`
        
        try {
          const response = await fetch(test.url, { method: 'HEAD', redirect: 'manual' })
          result += `状态: HTTP ${response.status}\n`
          
          if (response.status === 302 || response.status === 301) {
            const location = response.headers.get('location') || '无重定向'
            result += `重定向: ${location}\n`
          }
        } catch (error: any) {
          result += `错误: ${error.message}\n`
        }
        
        result += '\n'
      }
      
      setTestResult(result)
    } catch (error: any) {
      setTestResult(`测试失败: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const checkConfig = () => {
    const config = `
📋 当前配置检查:
================

✅ 环境变量配置:
• Client ID: 4e171b56-e2bf-424d-86dd-b63dde0f9634
• Client Secret: 已配置
• API Base: https://api.mindverse.com/gate/lab
• NEXTAUTH_SECRET: 已配置

🔧 需要你在Second Me平台检查的:
================================

1. 🔑 应用状态:
   访问: https://develop.second.me
   检查: 应用是否显示"已启用"

2. 🔗 重定向URI:
   必须包含: http://localhost:3000/api/auth/callback/secondme
   注意: 必须是 exact match

3. 📝 保存配置:
   任何修改后必须点击"保存"按钮

🚀 测试链接:
===========

1. 最小scope测试:
   https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid

2. 复制这个URL到浏览器测试

📞 报告格式:
===========

请提供:
1. Second Me平台截图
2. 错误页面截图
3. 具体错误信息
`
    setTestResult(config)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">🚨 OAuth 紧急诊断</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-red-50 border border-red-200 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-red-800 mb-4">问题诊断</h2>
              <ul className="space-y-3 text-red-700">
                <li className="flex items-start">
                  <span className="mr-2">❌</span>
                  <span>三个测试URL都失败</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">🔍</span>
                  <span>最可能：Second Me应用未启用</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">⚠️</span>
                  <span>需要立即检查平台配置</span>
                </li>
              </ul>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-blue-800 mb-4">解决方案</h2>
              <ol className="space-y-3 text-blue-700 list-decimal list-inside">
                <li>登录 develop.second.me</li>
                <li>检查应用状态</li>
                <li>确认重定向URI</li>
                <li>保存配置</li>
                <li>重新测试</li>
              </ol>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <button
              onClick={testDirectOAuth}
              disabled={loading}
              className="w-full py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              {loading ? '测试中...' : '🧪 运行OAuth测试'}
            </button>

            <button
              onClick={checkConfig}
              className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
            >
              📋 显示配置检查清单
            </button>
          </div>

          {testResult && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">测试结果</h2>
              <pre className="whitespace-pre-wrap font-mono text-sm bg-white p-4 rounded-lg overflow-auto max-h-96">
                {testResult}
              </pre>
            </div>
          )}
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h2 className="text-xl font-semibold text-yellow-800 mb-4">🎯 立即行动</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-yellow-600">1</span>
              </div>
              <div>
                <h3 className="font-medium text-yellow-900">登录Second Me平台</h3>
                <p className="text-yellow-700 text-sm">访问: https://develop.second.me</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-yellow-600">2</span>
              </div>
              <div>
                <h3 className="font-medium text-yellow-900">检查应用配置</h3>
                <p className="text-yellow-700 text-sm">确认：已启用 + 正确重定向URI</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-yellow-600">3</span>
              </div>
              <div>
                <h3 className="font-medium text-yellow-900">截图发给我</h3>
                <p className="text-yellow-700 text-sm">应用状态 + 错误页面</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}