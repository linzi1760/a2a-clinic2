'use client'

import { useSession, signIn, signOut } from 'next-auth/react'
import { useEffect, useState } from 'react'
import { getSecondMeAPI } from '@/lib/secondme'

export default function TestLoginPage() {
  const { data: session, status } = useSession()
  const [apiTestResult, setApiTestResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const testAPI = async () => {
    if (!session?.accessToken) return
    
    setLoading(true)
    setError(null)
    
    try {
      const secondMe = getSecondMeAPI(session.accessToken as string)
      
      // 测试1: 获取用户信息
      const userInfo = await secondMe.getUserInfo()
      
      // 测试2: 获取兴趣标签
      const shades = await secondMe.getUserShades()
      
      setApiTestResult({
        user: {
          id: userInfo.id,
          name: userInfo.name,
          email: userInfo.email,
          bio: userInfo.bio,
        },
        interests: shades.map((s: any) => ({
          name: s.shadeName,
          confidence: s.confidenceLevel,
        })),
        timestamp: new Date().toISOString(),
      })
    } catch (err: any) {
      setError(err.message || 'API测试失败')
      console.error('API测试错误:', err)
    } finally {
      setLoading(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="mb-4 inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="text-gray-600">加载中...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Second Me 登录测试</h1>
          
          {!session ? (
            <div className="text-center py-12">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100 mb-4">
                  <span className="text-2xl">🔐</span>
                </div>
                <h2 className="text-xl font-semibold text-gray-900">请先登录</h2>
                <p className="text-gray-600 mt-2">使用你的 Second Me 账号登录以测试API</p>
              </div>
              <button
                onClick={() => signIn('secondme')}
                className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:opacity-90"
              >
                用 Second Me 登录
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {/* 用户信息 */}
              <div className="bg-blue-50 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">登录成功！</h2>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <span className="text-gray-600 w-24">用户:</span>
                    <span className="font-medium">{session.user?.name}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-gray-600 w-24">邮箱:</span>
                    <span className="font-medium">{session.user?.email || '未设置'}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-gray-600 w-24">Token:</span>
                    <span className="font-mono text-sm truncate">
                      {session.accessToken ? '✅ 已获取' : '❌ 未获取'}
                    </span>
                  </div>
                </div>
              </div>

              {/* API测试 */}
              <div className="border rounded-xl p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">API 测试</h2>
                
                <div className="space-y-4">
                  <button
                    onClick={testAPI}
                    disabled={loading}
                    className="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 disabled:opacity-50"
                  >
                    {loading ? '测试中...' : '测试 Second Me API'}
                  </button>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <div className="flex items-center">
                        <span className="text-red-600 mr-2">❌</span>
                        <span className="font-medium text-red-800">错误:</span>
                      </div>
                      <p className="text-red-700 mt-1">{error}</p>
                    </div>
                  )}

                  {apiTestResult && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <span className="text-green-600 mr-2">✅</span>
                        <span className="font-medium text-green-800">API测试成功</span>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium text-gray-900 mb-2">用户信息</h3>
                          <div className="bg-white rounded-lg p-3">
                            <pre className="text-sm overflow-auto">
                              {JSON.stringify(apiTestResult.user, null, 2)}
                            </pre>
                          </div>
                        </div>

                        <div>
                          <h3 className="font-medium text-gray-900 mb-2">兴趣标签</h3>
                          <div className="bg-white rounded-lg p-3">
                            <div className="flex flex-wrap gap-2">
                              {apiTestResult.interests.map((interest: any, index: number) => (
                                <span
                                  key={index}
                                  className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                                >
                                  {interest.name} ({interest.confidence})
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="text-sm text-gray-500">
                          测试时间: {new Date(apiTestResult.timestamp).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* 下一步 */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">下一步</h2>
                <div className="space-y-3">
                  <p className="text-gray-700">
                    ✅ API测试成功后，你可以：
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-2 ml-4">
                    <li>访问 <a href="/clinic/lobby" className="text-blue-600 hover:underline">诊所大厅</a> 提交病例</li>
                    <li>测试诊断对话功能</li>
                    <li>开始真正的开发工作</li>
                  </ul>
                </div>
              </div>

              {/* 登出按钮 */}
              <div className="text-center">
                <button
                  onClick={() => signOut()}
                  className="px-6 py-3 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50"
                >
                  退出登录
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 技术信息 */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Client ID: {process.env.NEXT_PUBLIC_SECONDME_CLIENT_ID ? '已配置' : '未配置'}</p>
          <p>API Base: {process.env.SECONDME_API_BASE || '未配置'}</p>
          <p>环境: {process.env.NODE_ENV}</p>
        </div>
      </div>
    </div>
  )
}