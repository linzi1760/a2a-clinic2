'use client'

import { signIn, signOut, useSession } from 'next-auth/react'
import { useState } from 'react'

export default function SimpleTestPage() {
  const { data: session, status } = useSession()
  const [testResult, setTestResult] = useState<string>('')

  const testConfig = async () => {
    setTestResult('测试中...')
    
    try {
      // 直接测试环境变量
      const hasClientId = !!process.env.NEXT_PUBLIC_SECONDME_CLIENT_ID
      const hasClientSecret = !!process.env.SECONDME_CLIENT_SECRET
      const hasApiBase = !!process.env.SECONDME_API_BASE
      
      let result = '配置检查:\n'
      result += `Client ID: ${hasClientId ? '✅ 已配置' : '❌ 未配置'}\n`
      result += `Client Secret: ${hasClientSecret ? '✅ 已配置' : '❌ 未配置'}\n`
      result += `API Base: ${hasApiBase ? '✅ 已配置' : '❌ 未配置'}\n`
      result += `登录状态: ${session ? '✅ 已登录' : '❌ 未登录'}\n`
      
      if (session?.accessToken) {
        result += `Access Token: ✅ 已获取\n`
      }
      
      setTestResult(result)
    } catch (error: any) {
      setTestResult(`测试失败: ${error.message}`)
    }
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="mb-4 inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="text-gray-600">加载中...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md p-6 mt-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">A2A Clinic 简单测试</h1>
        
        <div className="space-y-6">
          {/* 登录状态 */}
          <div className="border rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">登录状态</h2>
            {!session ? (
              <div className="text-center">
                <p className="text-gray-600 mb-4">请先登录</p>
                <button
                  onClick={() => signIn('secondme')}
                  className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
                >
                  用 Second Me 登录
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-green-50 rounded-lg p-3">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center mr-3">
                      <span className="text-white text-sm">✓</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{session.user?.name}</p>
                      <p className="text-sm text-gray-600">{session.user?.email}</p>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => signOut()}
                  className="w-full py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
                >
                  退出登录
                </button>
              </div>
            )}
          </div>

          {/* 配置测试 */}
          <div className="border rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">配置测试</h2>
            <button
              onClick={testConfig}
              className="w-full py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 mb-4"
            >
              测试配置
            </button>
            
            {testResult && (
              <div className="bg-gray-50 rounded-lg p-3">
                <pre className="text-sm whitespace-pre-wrap font-mono">{testResult}</pre>
              </div>
            )}
          </div>

          {/* 下一步 */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">下一步</h2>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• 如果登录成功，访问 <a href="/" className="text-blue-600 hover:underline">主页</a></li>
              <li>• 测试诊断功能</li>
              <li>• 开始开发核心功能</li>
            </ul>
          </div>

          {/* 技术支持 */}
          <div className="text-center text-sm text-gray-500">
            <p>遇到问题？检查：</p>
            <ul className="mt-1 space-y-1">
              <li>• .env.local 文件中的配置</li>
              <li>• Second Me 应用是否已启用</li>
              <li>• 重定向URI配置</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}