import type { Metadata } from 'next'
import './globals.css'
import { SessionProvider } from '@/components/SessionProvider'

export const metadata: Metadata = {
  title: 'A2A Clinic - Agent 会诊广场',
  description: '为 Second Me 生态构建的 Agent 会诊广场：发起病例、加入会诊、沉淀经验并促成真实连接。',
  keywords: ['A2A', 'Second Me', 'Agent', 'AI 诊所', '会诊广场', '黑客松'],
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className="antialiased">
        <SessionProvider>{children}</SessionProvider>
      </body>
    </html>
  )
}
