'use client'

import { useState } from 'react'

export default function EmergencyTestPage() {
  const [step, setStep] = useState(1)

  const testLinks = [
    {
      name: '最小scope测试',
      url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid',
      description: '只请求openid权限'
    },
    {
      name: '基础scope测试', 
      url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid%20profile%20email',
      description: '请求基本信息权限'
    },
    {
      name: '完整scope测试',
      url: 'https://develop.second.me/oauth/authorize?client_id=4e171b56-e2bf-424d-86dd-b63dde0f9634&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fcallback%2Fsecondme&response_type=code&scope=openid%20profile%20email%20agent%3Aconverse%20memory%3Aread%20memory%3Awrite',
      description: '请求所有权限'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* 头部 */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-red-500 to-orange-500 mb-4">
            <span className="text-3xl text-white">🚨</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900">OAuth 紧急诊断</h1>
          <p className="text-gray-600 mt-2">三个测试链接都失败 - 需要立即检查Second Me平台配置</p>
        </div>

        {/* 步骤指示器 */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3].map((num) => (
              <div key={num} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= num ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                  {num}
                </div>
                {num < 3 && <div className="w-16 h-1 bg-gray-200"></div>}
              </div>
            ))}
          </div>
        </div>

        {/* 步骤内容 */}
        <div className="space-y-8">
          {/* 步骤1：检查平台 */}
          {step === 1 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">步骤1：检查Second Me平台配置</h2>
              
              <div className="space-y-6">
                <div className="bg-blue-50 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-blue-800 mb-4">立即行动</h3>
                  <ol className="space-y-4 text-blue-700">
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                        <span className="font-bold">1</span>
                      </div>
                      <div>
                        <p className="font-medium">登录Second Me平台</p>
                        <p className="text-sm opacity-80">访问: <a href="https://develop.second.me" target="_blank" className="underline">https://develop.second.me</a></p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                        <span className="font-bold">2</span>
                      </div>
                      <div>
                        <p className="font-medium">找到"A2A Clinic"应用</p>
                        <p className="text-sm opacity-80">检查应用管理页面</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                        <span className="font-bold">3</span>
                      </div>
                      <div>
                        <p className="font-medium">检查关键配置</p>
                        <ul className="text-sm opacity-80 mt-1 space-y-1">
                          <li>• 应用状态: <strong>必须显示"已启用"</strong></li>
                          <li>• 重定向URI: <strong>必须包含 http://localhost:3000/api/auth/callback/secondme</strong></li>
                        </ul>
                      </div>
                    </li>
                  </ol>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-yellow-800 mb-4">需要你提供的截图</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4">
                      <div className="text-center mb-2">
                        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-yellow-100 mb-2">
                          <span className="text-yellow-600">📱</span>
                        </div>
                        <p className="font-medium">应用状态截图</p>
                      </div>
                      <p className="text-sm text-gray-600">显示应用是否"已启用"</p>
                    </div>
                    <div className="bg-white rounded-lg p-4">
                      <div className="text-center mb-2">
                        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-yellow-100 mb-2">
                          <span className="text-yellow-600">🔗</span>
                        </div>
                        <p className="font-medium">重定向URI截图</p>
                      </div>
                      <p className="text-sm text-gray-600">显示配置的重定向URI</p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 text-lg"
                >
                  我已检查平台配置，继续下一步
                </button>
              </div>
            </div>
          )}

          {/* 步骤2：测试链接 */}
          {step === 2 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">步骤2：测试OAuth链接</h2>
              
              <div className="space-y-6">
                <div className="bg-green-50 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-green-800 mb-4">测试说明</h3>
                  <p className="text-green-700">
                    点击下面的测试链接，观察结果并截图错误页面发给我。
                  </p>
                </div>

                <div className="space-y-4">
                  {testLinks.map((link, index) => (
                    <div key={index} className="border rounded-xl p-6 hover:border-blue-300 transition-colors">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-semibold text-gray-900">{link.name}</h4>
                          <p className="text-sm text-gray-600 mt-1">{link.description}</p>
                        </div>
                        <span className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                          测试 {index + 1}
                        </span>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-sm text-gray-500 mb-2">测试URL:</p>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <code className="text-sm break-all">{link.url}</code>
                        </div>
                      </div>
                      
                      <a
                        href={link.url}
                        target="_blank"
                        className="inline-block w-full py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-semibold rounded-lg hover:opacity-90 text-center"
                      >
                        🔗 点击测试此链接
                      </a>
                    </div>
                  ))}
                </div>

                <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-red-800 mb-4">⚠️ 重要提示</h3>
                  <ul className="space-y-2 text-red-700">
                    <li className="flex items-start">
                      <span className="mr-2">📸</span>
                      <span>测试后请截图错误页面</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">📋</span>
                      <span>复制完整的错误信息</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">🔍</span>
                      <span>注意浏览器地址栏的完整URL</span>
                    </li>
                  </ul>
                </div>

                <div className="flex space-x-4">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 py-3 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50"
                  >
                    返回上一步
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    className="flex-1 py-3 bg-green-600 text-white font-semibold rounded-xl hover:bg-green-700"
                  >
                    我已测试并截图，继续下一步
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 步骤3：报告结果 */}
          {step === 3 && (
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">步骤3：报告测试结果</h2>
              
              <div className="space-y-6">
                <div className="bg-purple-50 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-purple-800 mb-4">需要你提供的信息</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-lg p-4 text-center">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 mb-3">
                        <span className="text-purple-600">1</span>
                      </div>
                      <p className="font-medium text-gray-900">平台配置截图</p>
                      <p className="text-sm text-gray-600 mt-1">Second Me应用配置</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 mb-3">
                        <span className="text-purple-600">2</span>
                      </div>
                      <p className="font-medium text-gray-900">错误页面截图</p>
                      <p className="text-sm text-gray-600 mt-1">OAuth测试错误</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 mb-3">
                        <span className="text-purple-600">3</span>
                      </div>
                      <p className="font-medium text-gray-900">错误信息文字</p>
                      <p className="text-sm text-gray-600 mt-1">完整的错误描述</p>
                    </div>
                  </div>
                </div>

                <div className="border rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">报告格式</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <pre className="text-sm whitespace-pre-wrap">
{`1. Second Me平台配置:
   应用状态: [已启用/禁用]
   重定向URI: [配置内容]

2. 测试结果:
   最小scope测试: [成功/失败 + 错误信息]
   基础scope测试: [成功/失败 + 错误信息]
   完整scope测试: [成功/失败 + 错误信息]

3. 截图:
   [已发送平台配置截图]
   [已发送错误页面截图]`}
                    </pre>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">🎯 下一步行动</h3>
                  <p className="text-gray-700 mb-4">
                    根据你提供的测试结果，我将：
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <span className="mr-2">🔧</span>
                      <span>分析错误原因并提供解决方案</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">🚀</span>
                      <span>创建临时mock方案继续开发</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">📞</span>
                      <span>如果需要，联系Second Me技术支持</span>
                    </li>
                  </ul>
                </div>

                <div className="text-center">
                  <p className="text-gray-600 mb-4">请将测试结果和截图发给我</p>
                  <button
                    onClick={() => setStep(1)}
                    className="px-8 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700"
                  >
                    🔄 重新开始检查
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 底部信息 */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>A2A Clinic - Agent智能诊所 | 紧急诊断工具</p>
          <p className="mt-1">诊断时间: {new Date().toLocaleString()}</p>
        </div>
      </div>
    </div>
  )
}