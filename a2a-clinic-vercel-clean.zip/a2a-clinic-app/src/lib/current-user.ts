import { cookies } from 'next/headers'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'

export interface CurrentUser {
  id: string
  name: string
  email?: string | null
  image?: string | null
  accessToken?: string
  authType: 'secondme' | 'dev'
}

export async function getCurrentUser(): Promise<CurrentUser | null> {
  const session = await getServerSession(authOptions)

  if (session?.user?.id) {
    return {
      id: session.user.id,
      name: session.user.name || 'Second Me 用户',
      email: session.user.email,
      image: session.user.image,
      accessToken: session.accessToken,
      authType: 'secondme',
    }
  }

  if (process.env.NODE_ENV === 'development') {
    try {
      const cookieStore = await cookies()
      const devSession = cookieStore.get('dev-session')
      if (devSession) {
        const parsed = JSON.parse(devSession.value)
        return {
          id: parsed.id,
          name: parsed.name || '开发用户',
          email: parsed.email,
          image: parsed.avatar,
          authType: 'dev',
        }
      }
    } catch {
      return null
    }
  }

  return null
}
