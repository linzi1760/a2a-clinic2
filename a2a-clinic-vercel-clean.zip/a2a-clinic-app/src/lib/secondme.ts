import axios from 'axios'

export interface SecondMeUser {
  id: string
  name: string
  avatar?: string
  email?: string
  interests: string[]
  expertise: string[]
  bio?: string
  selfIntroduction?: string
  profileCompleteness?: number
  route?: string
}

export interface SecondMeShade {
  id: number
  shadeName: string
  shadeIcon: string
  confidenceLevel: string
  shadeDescription: string
  hasPublicContent: boolean
}

export interface StreamChunk {
  type: 'session' | 'tool_call' | 'tool_result' | 'content' | 'done'
  data?: any
  content?: string
}

class SecondMeAPI {
  private readonly baseURL = process.env.SECONDME_API_BASE || 'https://api.mindverse.com/gate/lab'

  constructor(private readonly accessToken: string) {}

  private async request<T>(endpoint: string, options: any = {}): Promise<T> {
    if (!this.accessToken) {
      throw new Error('Access token required')
    }

    const response = await axios({
      url: `${this.baseURL}${endpoint}`,
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    })

    const data = response.data
    if (data?.code !== undefined && data.code !== 0) {
      throw new Error(data.message || `Second Me API error: ${data.code}`)
    }

    return data?.data ?? data
  }

  async getUserInfo(): Promise<SecondMeUser> {
    const response = await this.request<any>('/api/secondme/user/info')
    return {
      id: response.userId || response.id || response.route || 'unknown-user',
      name: response.name || 'Second Me 用户',
      email: response.email,
      avatar: response.avatar,
      interests: [],
      expertise: [],
      bio: response.bio,
      selfIntroduction: response.selfIntroduction,
      profileCompleteness: response.profileCompleteness,
      route: response.route,
    }
  }

  async getUserShades(): Promise<SecondMeShade[]> {
    const response = await this.request<any>('/api/secondme/user/shades')
    const shades = Array.isArray(response?.shades) ? response.shades : []
    return shades.map((shade: any) => ({
      id: Number(shade.id) || 0,
      shadeName: shade.shadeName || '未知标签',
      shadeIcon: shade.shadeIcon || '✨',
      confidenceLevel: shade.confidenceLevel || 'medium',
      shadeDescription: shade.shadeDescription || '',
      hasPublicContent: Boolean(shade.hasPublicContent),
    }))
  }

  async getSoftMemory(keyword?: string, pageNo = 1, pageSize = 20): Promise<{ list: any[]; total: number }> {
    let url = `/api/secondme/user/softmemory?pageNo=${pageNo}&pageSize=${pageSize}`
    if (keyword) {
      url += `&keyword=${encodeURIComponent(keyword)}`
    }
    return this.request(url)
  }

  async* converseWithAgentStream(
    message: string,
    options?: {
      sessionId?: string
      model?: 'anthropic/claude-sonnet-4-5' | 'google_ai_studio/gemini-2.0-flash'
      systemPrompt?: string
      enableWebSearch?: boolean
    }
  ): AsyncGenerator<StreamChunk, void, unknown> {
    const response = await fetch(`${this.baseURL}/api/secondme/chat/stream`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        'X-App-Id': 'a2a-clinic',
      },
      body: JSON.stringify({
        message,
        sessionId: options?.sessionId,
        model: options?.model || 'anthropic/claude-sonnet-4-5',
        systemPrompt: options?.systemPrompt,
        enableWebSearch: options?.enableWebSearch || false,
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Stream request failed: ${response.status} ${errorText}`)
    }

    const reader = response.body?.getReader()
    if (!reader) {
      throw new Error('No stream reader available')
    }

    const decoder = new TextDecoder()
    let currentEvent: string | null = null
    let buffer = ''

    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const rawLine of lines) {
          const line = rawLine.trimEnd()
          if (!line) continue

          if (line.startsWith('event: ')) {
            currentEvent = line.slice(7)
            continue
          }

          if (!line.startsWith('data: ')) continue
          const data = line.slice(6)

          if (data === '[DONE]') {
            yield { type: 'done' }
            return
          }

          try {
            const parsed = JSON.parse(data)
            if (currentEvent === 'session') {
              yield { type: 'session', data: parsed }
            } else if (currentEvent === 'tool_call') {
              yield { type: 'tool_call', data: parsed }
            } else if (currentEvent === 'tool_result') {
              yield { type: 'tool_result', data: parsed }
            } else if (parsed?.choices?.[0]?.delta?.content) {
              yield { type: 'content', content: parsed.choices[0].delta.content }
            }
          } catch {
            // 忽略无法解析的片段，避免影响主要流程
          }

          currentEvent = null
        }
      }
    } finally {
      reader.releaseLock()
    }
  }

  async getChatSessions(appId?: string): Promise<Array<{ sessionId: string; appId: string; lastMessage: string; lastUpdateTime: string; messageCount: number }>> {
    const suffix = appId ? `?appId=${encodeURIComponent(appId)}` : ''
    const response = await this.request<any>(`/api/secondme/chat/session/list${suffix}`)
    return response.sessions || []
  }

  async getChatMessages(sessionId: string): Promise<{ sessionId: string; messages: any[] }> {
    return this.request(`/api/secondme/chat/session/messages?sessionId=${encodeURIComponent(sessionId)}`)
  }

  async reportAgentMemory(
    channel: { kind: string; id?: string; url?: string; meta?: any },
    action: string,
    refs: Array<{ objectType: string; objectId: string; contentPreview?: string }>,
    options?: {
      actionLabel?: string
      displayText?: string
      eventDesc?: string
      importance?: number
      idempotencyKey?: string
    }
  ): Promise<{ eventId: number; isDuplicate: boolean }> {
    return this.request('/api/secondme/agent_memory/ingest', {
      method: 'POST',
      data: {
        channel,
        action,
        refs,
        actionLabel: options?.actionLabel,
        displayText: options?.displayText,
        eventDesc: options?.eventDesc,
        importance: options?.importance || 0.5,
        idempotencyKey: options?.idempotencyKey,
      },
    })
  }
}

export function getSecondMeAPI(accessToken?: string): SecondMeAPI {
  if (!accessToken) {
    throw new Error('Access token required')
  }
  return new SecondMeAPI(accessToken)
}

export default SecondMeAPI
